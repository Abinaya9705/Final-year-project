class MusicModule:
    def recommend_exercise(self, profile):
        # Example: Recommend rhythmic reading if phonological errors are high
        if profile.get('phonological_errors', 0) > 5:
            return "Try rhythmic reading exercises and rhymes."
        return "Standard reading practice recommended."
