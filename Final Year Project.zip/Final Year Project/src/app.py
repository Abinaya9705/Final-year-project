import streamlit as st
from modules.input_module import InputModule
from modules.tts_module import TTSModule
from modules.progress_module import ProgressModule
from models.gdlm import GDLM

input_module = InputModule()
tts_module = TTSModule()
progress_module = ProgressModule()
gdlm = GDLM()

st.set_page_config(page_title="Dyslexia Learning & Diagnostic System", layout="wide")

# Sidebar for educator/parent dashboard
st.sidebar.header("Educator/Parent Dashboard")
if st.sidebar.button("Show Progress Dashboard"):
    st.sidebar.subheader("Error Analytics")
    error_stats = progress_module.get_error_stats()
    st.sidebar.pyplot(progress_module.plot_error_pie(error_stats))
    st.sidebar.subheader("Words Struggled With")
    st.sidebar.write(progress_module.get_struggled_words())
    st.sidebar.subheader("Recommendations")
    st.sidebar.write(progress_module.get_recommendations())

# Main student interface
st.title("Adaptive Multisensory Learning System")

# Input text area
user_text = st.text_area("Enter text to read or practice:")
if st.button("Analyze & Read Aloud"):
    analysis = gdlm.analyze(user_text)
    tts_module.speak_streamlit(user_text, analysis)
    st.markdown(f"**Feedback:** {progress_module.get_feedback(analysis)}")
    st.image(progress_module.get_visual_aid(user_text))
    st.write("Interactive activities coming soon!")
    progress_module.update(user_text, analysis)

# Music & Rhythm module integration
if st.button("Recommend Rhythmic Exercise"):
    from modules.music_module import MusicModule
    music_module = MusicModule()
    profile = progress_module.get_profile()
    st.write(music_module.recommend_exercise(profile))
