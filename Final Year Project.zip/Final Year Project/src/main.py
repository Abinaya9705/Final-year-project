from modules.input_module import InputModule
from modules.tts_module import TTSModule
from modules.progress_module import ProgressModule
from models.gdlm import GDLM

# Initialize modules
input_module = InputModule()
tts_module = TTSModule()
progress_module = ProgressModule()
gdlm = GDLM()

def main():
    # Get user input
    user_text = input_module.get_input()
    # Analyze with GDLM
    analysis = gdlm.analyze(user_text)
    # TTS feedback
    tts_module.speak(user_text, analysis)
    # Update progress/profile
    progress_module.update(user_text, analysis)
    # Show dashboard
    progress_module.show_dashboard()

if __name__ == "__main__":
    main()
