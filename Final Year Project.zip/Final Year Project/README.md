# Personalized Dyslexia Learning and Diagnostic System

## Overview
This project is an evolution from a simple dyslexia tutor to a data-driven, adaptive learning and diagnostic system powered by a Global Dyslexia Language Model (GDLM).

## Architecture
- **GDLM (Global Dyslexia Language Model):** Core NLP model for error analysis, diagnosis, and personalized feedback.
- **Input Module:** Handles text input and file uploads, passing data to GDLM.
- **TTS Module:** Uses pyttsx3 for adaptive text-to-speech, enhanced by GDLM's phonological analysis.
- **Progress & Feedback Module:** Tracks user errors, profiles, and analytics using SQLite and Matplotlib/Plotly.
- **Music & Rhythm Module:** Provides rhythmic reading exercises based on user profile.

## Directory Structure
- `src/` — Main application logic and orchestration
- `models/` — GDLM model code and checkpoints
- `data/` — Dyslexic-specific corpus and datasets
- `modules/` — Individual modules (input, tts, feedback, music)
- `docs/` — Documentation and research

## Key Workflows
- **Build:** Standard Python workflow; install dependencies from `requirements.txt`.
- **Run:** Launch main app from `src/main.py`.
- **Test:** Add tests in `src/tests/` and run with `pytest`.
- **Data:** Place corpus files in `data/`.
- **Model:** Train/fine-tune GDLM in `models/`.

## Integration Points
- GDLM is called by Input Module and returns error analysis to TTS and Feedback modules.
- Progress Module updates user profile and dashboard based on GDLM output.

## Conventions
- Use clear, modular Python code.
- Document new modules in `docs/` and update this README.
- Note new dependencies in `requirements.txt`.

---
*See `.github/copilot-instructions.md` for AI agent guidance.*
