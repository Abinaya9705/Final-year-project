from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import sqlite3

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# SQLite setup
conn = sqlite3.connect('dyslexia.db', check_same_thread=False)
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS progress (id INTEGER PRIMARY KEY, username TEXT, errors TEXT)''')
conn.commit()

class AnalyzeRequest(BaseModel):
    text: str

@app.post("/api/analyze")
def analyze(req: AnalyzeRequest):
    # Placeholder: return mock error analysis
    errors = []
    if "teh" in req.text:
        errors.append({"type": "orthographic", "word": "teh"})
    if "recieve" in req.text:
        errors.append({"type": "phonological", "word": "recieve"})
    return {"errors": errors, "feedback": "Analysis complete."}

@app.get("/api/progress")
def get_progress(username: str):
    c.execute("SELECT errors FROM progress WHERE username=?", (username,))
    row = c.fetchone()
    return {"username": username, "errors": row[0] if row else "[]"}

@app.post("/api/progress")
def update_progress(username: str, errors: str):
    c.execute("INSERT INTO progress (username, errors) VALUES (?, ?)", (username, errors))
    conn.commit()
    return {"status": "updated"}

@app.get("/api/recommendations")
def get_recommendations(username: str):
    # Placeholder: return mock recommendations
    return {"recommendations": ["Practice with rhyming games.", "Try visual spelling activities."]}
