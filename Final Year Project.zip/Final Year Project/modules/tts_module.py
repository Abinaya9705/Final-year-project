import pyttsx3
import streamlit as st

class TTSModule:
    def __init__(self):
        self.engine = pyttsx3.init()

    def speak(self, text, analysis):
        # Example: Slow down for challenging words
        for error in analysis.get('errors', []):
            if error['type'] == 'common dyslexic error':
                self.engine.setProperty('rate', 125)
            else:
                self.engine.setProperty('rate', 175)
        self.engine.say(text)
        self.engine.runAndWait()

    def speak_streamlit(self, text, analysis):
        # For Streamlit: highlight words as TTS would
        words = text.split()
        highlighted = []
        for word in words:
            if word.lower() in [e['token'] for e in analysis.get('errors', [])]:
                highlighted.append(f"<span style='background-color:yellow'>{word}</span>")
            else:
                highlighted.append(word)
        st.markdown(' '.join(highlighted), unsafe_allow_html=True)
