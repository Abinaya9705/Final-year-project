# Copilot Instructions for AI Coding Agents


## Project Overview
This project is a Personalized Dyslexia Learning and Diagnostic System powered by a Global Dyslexia Language Model (GDLM). It actively analyzes, diagnoses, and adapts to individual dyslexic challenges, providing multisensory, data-driven support.

## Architecture & Key Components
- `models/gdlm.py`: Core NLP model for dyslexia-specific error analysis and diagnosis.
- `modules/input_module.py`: Handles text input and file uploads; passes data to GDLM.
- `modules/tts_module.py`: Text-to-speech (pyttsx3), adapts speech rate/voice using GDLM analysis.
- `modules/progress_module.py`: Tracks user errors, profiles, and analytics (SQLite + Matplotlib).
- `modules/music_module.py`: Recommends rhythmic reading exercises based on user profile.
- `src/main.py`: Orchestrates flow between modules.

## Developer Workflows
- **Install dependencies:** `pip install -r requirements.txt`
- **Run main app:** `python src/main.py`
- **Add data:** Place dyslexic corpus files in `data/`
- **Model training:** Fine-tune GDLM in `models/` (see README for details)
- **Testing:** Add tests in `src/tests/` and run with `pytest`

## Project-Specific Patterns
- All user input is processed by GDLM before reaching other modules.
- GDLM returns detailed error analysis (letter reversals, phonological errors, etc.)
- TTS adapts feedback based on error types (e.g., slows down for challenging words).
- Progress module builds a personalized dyslexia profile and visualizes error trends.
- Music module recommends exercises based on profile analytics.

## Integration Points
- GDLM is the central intelligence; all modules interact with its output.
- Progress & Feedback module uses GDLM analysis for adaptive recommendations.

## Conventions
- Use modular Python code and document new modules in `docs/`.
- Update `requirements.txt` for new dependencies.
- Reference key files and update this guide as the project evolves.

---
*This file guides AI agents. Update as architecture and workflows change.*
