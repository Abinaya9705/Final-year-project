# Frontend: Dyslexia Learning & Diagnostic System

This is the React + Tailwind CSS frontend for the Personalized Dyslexia Learning and Diagnostic System.

## Features
- Student UI: Gamified lessons, drag-and-drop spelling games, TTS, adaptive feedback, animated rewards
- Educator Dashboard: Progress analytics, error breakdown, recommendations
- Responsive, modern design

## Getting Started
1. Install dependencies:
   ```
   npm install
   ```
2. Start development server:
   ```
   npm start
   ```

## Tech Stack
- React
- Tailwind CSS
- D3.js (for charts)
- Framer Motion (for animations)
- React DnD (for drag-and-drop)

## API
Connects to the FastAPI backend at `/api`.
