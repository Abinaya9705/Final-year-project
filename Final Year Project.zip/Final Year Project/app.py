
import streamlit as st
from modules.input_module import InputModule
from modules.tts_module import TTSModule
from modules.progress_module import ProgressModule
from models.gdlm import GDLM
import random

input_module = InputModule()
tts_module = TTSModule()
progress_module = ProgressModule()
gdlm = GDLM()

st.set_page_config(page_title="Dyslexia Learning & Diagnostic System", layout="wide")

# Session state for streaks and points
if 'streak' not in st.session_state:
    st.session_state['streak'] = 0
if 'points' not in st.session_state:
    st.session_state['points'] = 0
if 'last_correct' not in st.session_state:
    st.session_state['last_correct'] = False

# Sidebar for educator/parent dashboard
st.sidebar.header("Educator/Parent Dashboard")
if st.sidebar.button("Show Progress Dashboard"):
    st.sidebar.subheader("Error Analytics")
    error_stats = progress_module.get_error_stats()
    st.sidebar.pyplot(progress_module.plot_error_pie(error_stats))
    st.sidebar.subheader("Words Struggled With")
    st.sidebar.write(progress_module.get_struggled_words())
    st.sidebar.subheader("Recommendations")
    st.sidebar.write(progress_module.get_recommendations())

# Main student interface
st.title("Duolingo-style Dyslexia Learning System 🦉")
st.markdown(f"**Streak:** {st.session_state['streak']} 🔥 | **Points:** {st.session_state['points']} ⭐")

# Input text or image
input_type = st.radio("Choose input type:", ["Text", "Image (URL)"])
if input_type == "Text":
    user_text = st.text_area("Enter text you find difficult or want to practice:")
else:
    user_text = st.text_input("Paste image URL containing text you find difficult:")
    if user_text:
        st.image(user_text, caption="Your input image")

# Adaptive reading and feedback
if st.button("Analyze & Help Me Read!") and user_text:
    analysis = gdlm.analyze(user_text)
    tts_module.speak_streamlit(user_text, analysis)
    st.markdown(f"**Feedback:** {progress_module.get_feedback(analysis)}")
    st.image(progress_module.get_visual_aid(user_text))
    progress_module.update(user_text, analysis)
    if analysis['errors']:
        st.session_state['streak'] = 0
        st.session_state['last_correct'] = False
        st.warning("Let's practice more! Try the game below to improve.")
    else:
        st.session_state['points'] += 10
        if st.session_state['last_correct']:
            st.session_state['streak'] += 1
        else:
            st.session_state['streak'] = 1
        st.session_state['last_correct'] = True
        st.success("Great job! No dyslexic errors detected. Keep your streak going!")

# Gamified word-matching exercise
st.subheader("Word-Matching Game 🕹️")
game_words = ["teh", "adn", "recieve", "b", "d", "p", "q", "cat", "dog", "the", "and", "receive"]
target_word = random.choice([w for w in game_words if w in ["teh", "adn", "recieve", "b", "d", "p", "q"]])
options = [target_word, "the", "and", "receive", "cat", "dog"]
random.shuffle(options)
st.write(f"Which is the correct spelling for: **{target_word}**?")
selected = st.radio("Choose your answer:", options)
if st.button("Check Answer"):
    if selected in ["the", "and", "receive"]:
        st.session_state['points'] += 5
        st.session_state['streak'] += 1
        st.success("Correct! You earned 5 points and increased your streak.")
    else:
        st.session_state['streak'] = 0
        st.warning("Oops! That's a common dyslexic error. Try again!")

# Music & Rhythm module integration
if st.button("Recommend Rhythmic Exercise"):
    from modules.music_module import MusicModule
    music_module = MusicModule()
    profile = progress_module.get_profile()
    st.write(music_module.recommend_exercise(profile))

# Show badges for streaks
if st.session_state['streak'] >= 3:
    st.balloons()
    st.markdown("🏅 **Streak Badge Unlocked!** Keep going!")
