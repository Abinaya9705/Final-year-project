# Backend: Dyslexia Learning & Diagnostic System

This is the FastAPI backend for the Personalized Dyslexia Learning and Diagnostic System.

## Features
- REST API for student analysis, progress tracking, recommendations
- Integration with GDLM (Global Dyslexia Language Model)
- SQLite database for user data and analytics

## Getting Started
1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
2. Start development server:
   ```
   uvicorn main:app --reload
   ```

## Tech Stack
- FastAPI
- Python
- SQLite

## API Endpoints
- `/api/analyze` - Analyze student input
- `/api/progress` - Get/update progress
- `/api/recommendations` - Get personalized recommendations
