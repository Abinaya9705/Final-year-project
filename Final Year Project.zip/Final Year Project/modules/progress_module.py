
import sqlite3
import matplotlib.pyplot as plt
import streamlit as st

class ProgressModule:
    def __init__(self):
        self.conn = sqlite3.connect('progress.db')
        self.create_table()

    def create_table(self):
        c = self.conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS progress
                     (text TEXT, errors TEXT)''')
        self.conn.commit()

    def update(self, text, analysis):
        c = self.conn.cursor()
        c.execute("INSERT INTO progress (text, errors) VALUES (?, ?)",
                  (text, str(analysis.get('errors', []))))
        self.conn.commit()

    def get_error_stats(self):
        c = self.conn.cursor()
        c.execute("SELECT errors FROM progress")
        errors = c.fetchall()
        error_types = {}
        for row in errors:
            for error in eval(row[0]):
                etype = error['type']
                error_types[etype] = error_types.get(etype, 0) + 1
        return error_types

    def plot_error_pie(self, error_stats):
        fig, ax = plt.subplots()
        ax.pie(error_stats.values(), labels=error_stats.keys(), autopct='%1.1f%%')
        ax.set_title('Error Type Breakdown')
        return fig

    def get_struggled_words(self):
        c = self.conn.cursor()
        c.execute("SELECT errors FROM progress")
        errors = c.fetchall()
        words = set()
        for row in errors:
            for error in eval(row[0]):
                words.add(error['token'])
        return list(words)

    def get_recommendations(self):
        error_stats = self.get_error_stats()
        if error_stats.get('phonological', 0) > 2:
            return "Recommend more rhythmic reading exercises."
        return "Standard reading practice recommended."

    def get_feedback(self, analysis):
        if not analysis['errors']:
            return "Great job! No dyslexic errors detected."
        feedback = []
        for error in analysis['errors']:
            if error['type'] == 'letter_reversal':
                feedback.append(f"Letter reversal detected in '{error['token']}'. Try visualizing the correct letter order.")
            elif error['type'] == 'phonological':
                feedback.append(f"Phonological confusion with '{error['token']}'. Practice with rhymes or rhythm.")
        return ' '.join(feedback)

    def get_visual_aid(self, text):
        # Placeholder: return a static image or diagram
        return "https://upload.wikimedia.org/wikipedia/commons/3/3a/Cat03.jpg"

    def get_profile(self):
        return self.get_error_stats()
