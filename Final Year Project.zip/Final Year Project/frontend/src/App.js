import React, { useState } from 'react';
import { motion } from 'framer-motion';
import './App.css';

function App() {
  const [view, setView] = useState('home');
  const [text, setText] = useState('');
  const [feedback, setFeedback] = useState('');
  const [errors, setErrors] = useState([]);
  const [username, setUsername] = useState('student1');

  // TTS
  const [ttsPlaying, setTtsPlaying] = useState(false);
  const [ttsSpeed, setTtsSpeed] = useState(1);
  const speakText = () => {
    const utter = new window.SpeechSynthesisUtterance(text);
    utter.rate = ttsSpeed;
    window.speechSynthesis.speak(utter);
    setTtsPlaying(true);
    utter.onend = () => setTtsPlaying(false);
  };

  // Analyze text (mock API)
  const analyzeText = async () => {
    const res = await fetch('http://localhost:8000/api/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });
    const data = await res.json();
    setErrors(data.errors);
    setFeedback(data.feedback);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-100 flex flex-col items-center justify-center">
      {view === 'home' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white rounded-2xl shadow-xl p-8 max-w-lg w-full text-center">
          <h1 className="text-3xl font-bold text-purple-700 mb-4">A.I. Multisensory Tutor for Dyslexia</h1>
          <p className="text-gray-600 mb-8">Empowering students and educators with adaptive, multisensory learning and diagnostics.</p>
          <div className="flex flex-col gap-4">
            <button onClick={() => setView('student')} className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-xl shadow">Start Learning (Student)</button>
            <button onClick={() => setView('dashboard')} className="bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 rounded-xl shadow">View Dashboard (Educator/Parent)</button>
          </div>
        </motion.div>
      )}
      {view === 'student' && (
        <motion.div initial={{ x: 100, opacity: 0 }} animate={{ x: 0, opacity: 1 }} className="bg-white rounded-xl shadow-lg p-8 w-full max-w-2xl">
          <h2 className="text-2xl font-bold text-blue-700 mb-2">Reading Practice</h2>
          <textarea value={text} onChange={e => setText(e.target.value)} className="w-full p-2 border rounded mb-4" rows={3} placeholder="Enter text you find difficult..." />
          <div className="flex items-center gap-4 mb-4">
            <button onClick={speakText} className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg shadow">{ttsPlaying ? 'Stop' : 'Play'}</button>
            <label className="flex items-center gap-2">
              <span className="text-gray-600">Voice Speed</span>
              <input type="range" min="0.5" max="2" step="0.1" value={ttsSpeed} onChange={e => setTtsSpeed(e.target.value)} className="w-24" />
              <span className="text-gray-600">{ttsSpeed}x</span>
            </label>
          </div>
          <button onClick={analyzeText} className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg shadow mb-2">Analyze & Get Feedback</button>
          {feedback && <div className="mt-2 text-purple-700 font-semibold">{feedback}</div>}
          {errors.length > 0 && (
            <div className="mt-2 text-red-600 font-semibold">Errors: {errors.map(e => `${e.word} (${e.type})`).join(', ')}</div>
          )}
          <button onClick={() => setView('home')} className="mt-6 text-gray-500 hover:text-gray-700 underline">← Back to Home</button>
        </motion.div>
      )}
      {view === 'dashboard' && (
        <motion.div initial={{ x: -100, opacity: 0 }} animate={{ x: 0, opacity: 1 }} className="bg-white rounded-xl shadow-lg p-8 w-full max-w-2xl">
          <h2 className="text-2xl font-bold text-purple-700 mb-4">Educator/Parent Dashboard</h2>
          <div className="mb-4">(Dashboard features and charts go here)</div>
          <button onClick={() => setView('home')} className="mt-6 text-gray-500 hover:text-gray-700 underline">← Back to Home</button>
        </motion.div>
      )}
    </div>
  );
}

export default App;
