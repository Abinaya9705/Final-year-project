import torch
from transformers import AutoModelForMaskedLM, AutoTokenizer

class GDLM:
    def __init__(self, model_name='bert-base-uncased'):
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForMaskedLM.from_pretrained(model_name)
        self.error_patterns = {
            'letter_reversal': ['teh', 'adn', 'recieve'],
            'phonological': ['b', 'd', 'p', 'q'],
            'word_skip': ['missing', 'skipped'],
        }

    def analyze(self, text):
        tokens = self.tokenizer.tokenize(text)
        errors = self.detect_errors(tokens)
        return {'tokens': tokens, 'errors': errors}

    def detect_errors(self, tokens):
        error_types = []
        for token in tokens:
            for etype, patterns in self.error_patterns.items():
                if token.lower() in patterns:
                    error_types.append({'token': token, 'type': etype})
        return error_types
